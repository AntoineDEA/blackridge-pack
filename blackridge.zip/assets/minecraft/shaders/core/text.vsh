#version 330

// Blackridge : texte vanilla, plus des couleurs réservées qui deviennent des dégradés animés (voir text.fsh).
//   #01A9FE Rare (reflet bleu) · #A901FE Épique (reflet violet) · #FEA901 Légendaire (or brillant) · #FE01A9 Mythique (arc-en-ciel)
// L'ombre du texte (couleur × 0,25) est reconnue aussi, pour garder une ombre assortie.
// Voile plein écran (transitions, envoyé en titre avec le glyphe blackridge:ecran) : #FE0102 cercle qui se ferme,
// #FE0103 fondu au noir. Le fondu du titre (alpha) pilote l'avancée ; l'ombre du voile est cachée.

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;
out vec4 lightColor;
out float effect;
out float shade;
out float screenX;

// 1 à 4 si la couleur est réservée (ou son ombre), 0 sinon.
float marker(ivec3 c, out float s) {
    s = 1.0;
    if (c == ivec3(1, 169, 254)) return 1.0;
    if (c == ivec3(169, 1, 254)) return 2.0;
    if (c == ivec3(254, 169, 1)) return 3.0;
    if (c == ivec3(254, 1, 169)) return 4.0;
    s = 0.25;
    if (c == ivec3(0, 42, 63)) return 1.0;
    if (c == ivec3(42, 0, 63)) return 2.0;
    if (c == ivec3(63, 42, 0)) return 3.0;
    if (c == ivec3(63, 0, 42)) return 4.0;
    s = 1.0;
    return 0.0;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    lightColor = sample_lightmap(Sampler2, UV2);
#else
    lightColor = vec4(1.0);
#endif
    vertexColor = Color * lightColor;
    texCoord0 = UV0;

    effect = marker(ivec3(round(Color.rgb * 255.0)), shade);
    screenX = (gl_Position.x / gl_Position.w * 0.5 + 0.5) * ScreenSize.x;

    ivec3 c = ivec3(round(Color.rgb * 255.0));
    if (c == ivec3(254, 1, 2) || c == ivec3(254, 1, 3)) {
        // Le quad du glyphe couvre tout l'écran (sommets 0 à 3 de chaque quad, triangles 0-1-2 et 2-3-0).
        effect = c.b == 2 ? 5.0 : 6.0;
        int corner = gl_VertexID % 4;
        vec2 pos = corner == 0 ? vec2(-1.0, 1.0) : corner == 1 ? vec2(-1.0, -1.0) : corner == 2 ? vec2(1.0, -1.0) : vec2(1.0, 1.0);
        gl_Position = vec4(pos, 0.0, 1.0);
    } else if (c == ivec3(63, 0, 0)) {
        gl_Position = vec4(0.0);
    }
}
