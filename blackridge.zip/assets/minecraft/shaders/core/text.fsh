#version 330

// Blackridge : texte vanilla, plus les dégradés animés des raretés (couleurs réservées, voir text.vsh).

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif

#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif

in vec4 vertexColor;
in vec2 texCoord0;
in vec4 lightColor;
in float effect;
in float shade;
in float screenX;

out vec4 fragColor;

vec3 hsv(float h, float s, float v) {
    vec3 k = clamp(abs(mod(h * 6.0 + vec3(0.0, 4.0, 2.0), 6.0) - 3.0) - 1.0, 0.0, 1.0);
    return v * mix(vec3(1.0), k, s);
}

// Deux teintes qui ondulent, et un reflet blanc qui balaie le texte.
vec3 shine(vec3 a, vec3 b, float x, float t) {
    vec3 c = mix(a, b, 0.5 + 0.5 * sin(x * 0.05 - t * 1.6));
    float band = pow(max(sin(x * 0.035 - t * 2.6), 0.0), 28.0);
    return mix(c, vec3(1.0), band * 0.85);
}

vec3 rarity(float id, float x, float t) {
    if (id < 1.5) return shine(vec3(0.35, 0.85, 1.0), vec3(0.15, 0.5, 1.0), x, t);
    if (id < 2.5) return shine(vec3(0.78, 0.38, 1.0), vec3(1.0, 0.45, 0.88), x, t);
    if (id < 3.5) return shine(vec3(1.0, 0.62, 0.05), vec3(1.0, 0.9, 0.42), x, t);
    vec3 c = hsv(fract(x * 0.004 - t * 0.22), 0.62, 1.0);
    float band = pow(max(sin(x * 0.035 - t * 2.6), 0.0), 28.0);
    return mix(c, vec3(1.0), band * 0.6);
}

// Le voile : p va de 0 (ouvert) à 1 (noir), au rythme du fondu du titre.
vec4 veil(float id, float p) {
    if (id > 5.5) return vec4(0.0, 0.0, 0.0, p);
    vec2 uv = gl_FragCoord.xy / ScreenSize;
    float aspect = ScreenSize.x / ScreenSize.y;
    float d = length((uv - 0.5) * vec2(aspect, 1.0));
    float maxR = length(vec2(aspect, 1.0)) * 0.5 + 0.02;
    float r = (1.0 - p) * maxR;
    float px = 1.0 / ScreenSize.y;
    float outside = smoothstep(r - px, r + px, d);
    float ring = (1.0 - smoothstep(0.0, 5.0 * px, abs(d - r))) * step(0.002, r) * (1.0 - step(maxR - 0.02, r));
    return mix(vec4(0.0, 0.0, 0.0, outside), vec4(1.0, 0.78, 0.3, 1.0), ring);
}

void main() {
    if (effect > 4.5) {
        fragColor = veil(effect, vertexColor.a);
        return;
    }
#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif

    vec4 tint = vertexColor;
    if (effect > 0.5) {
        float t = GameTime * 1200.0;
        tint = vec4(rarity(effect, screenX, t) * shade, vertexColor.a) * lightColor;
    }

#ifdef IS_SEE_THROUGH
    vec4 color = texColor * tint;
#else
    vec4 color = texColor * tint * ColorModulator;
#endif
    if (color.a < 0.1) {
        discard;
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}
